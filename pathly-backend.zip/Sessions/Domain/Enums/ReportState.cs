﻿namespace pathly_backend.Sessions.Domain.Enums
{
    public enum ReportState
    {
        Pending,
        Accepted,
        Rejected
    }
}
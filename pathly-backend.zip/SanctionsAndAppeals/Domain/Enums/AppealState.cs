﻿namespace pathly_backend.SanctionsAndAppeals.Domain.Enums
{
    public enum AppealState
    {
        Pending,
        Accepted,
        Rejected
    }
}
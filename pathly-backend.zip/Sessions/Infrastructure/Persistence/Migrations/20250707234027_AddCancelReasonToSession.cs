﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace pathly_backend.Sessions.Infrastructure.Persistence.Migrations
{
    /// <inheritdoc />
    public partial class AddCancelReasonToSession : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CancelReason",
                table: "Sessions",
                type: "text",
                nullable: true)
                .Annotation("MySql:CharSet", "utf8mb4");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CancelReason",
                table: "Sessions");
        }
    }
}

﻿using System;

namespace pathly_backend.Sessions.Application.Dtos
{
    public record SendChatMessageDto(
        string Content
    );
}
﻿namespace pathly_backend.SanctionsAndAppeals.Application.Dtos
{
    public record ResolveAppealDto(string Action, string DecisionComment);
}
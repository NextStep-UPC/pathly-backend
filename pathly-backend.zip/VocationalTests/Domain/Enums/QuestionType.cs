﻿namespace pathly_backend.VocationalTests.Domain.Enums
{
    public enum QuestionType
    {
        SingleChoice,
        MultipleChoice,
        OpenEnded
    }
}
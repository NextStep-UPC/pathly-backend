﻿namespace pathly_backend.Sessions.Application.Dtos
{
    public record ResolveReportDto(
        string AdminComment,
        string Action
    );
}
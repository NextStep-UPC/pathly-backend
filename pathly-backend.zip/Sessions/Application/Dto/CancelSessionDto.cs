﻿namespace pathly_backend.Sessions.Application.Dto;

public record CancelSessionDto(string Reason);
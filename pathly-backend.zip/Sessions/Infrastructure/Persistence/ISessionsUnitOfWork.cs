﻿using pathly_backend.Shared.Common;

namespace pathly_backend.Sessions.Infrastructure.Persistence;

public interface ISessionsUnitOfWork : IUnitOfWork { }
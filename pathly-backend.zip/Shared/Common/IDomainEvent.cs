﻿namespace pathly_backend.Shared.Common;
public interface IDomainEvent { }
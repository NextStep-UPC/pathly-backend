﻿namespace pathly_backend.Sessions.Domain.Enums;

public enum SessionState
{
    Pending,
    Confirmed,
    Cancelled,
    Completed
}
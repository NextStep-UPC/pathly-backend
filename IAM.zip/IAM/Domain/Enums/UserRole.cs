﻿namespace pathly_backend.IAM.Domain.Enums;
public enum UserRole { Student = 0, Psychologist = 1, Admin = 2 }